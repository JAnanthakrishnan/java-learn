public class RightTriangle
{
  public static void main(String[] args) {
    boolean x;
    int a=Integer.parseInt(args[0]);
    int b=Integer.parseInt(args[1]);
    int c=Integer.parseInt(args[2]);

    x=(a>0)&&(b>0)&&(c>0)&&(c*c==(a*a+b*b));
    System.out.println(x);
  }
}
